require_relative '../lib/data_store'

require 'httparty'
require 'json'
require 'rspec/expectations'
require 'securerandom'

include RSpec::Matchers.dup